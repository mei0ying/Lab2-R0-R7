package Core;
/**
 * ������1.0
 * 10/10/2018
 */
import java.util.ArrayList;

public class DataBase {

	//����Ļ��ʾ
	private String mainText;
	int maxTextLength = 29;
	public ArrayList<Double> arrayList;
	String syn;
	double ans;

	public DataBase() {
		setMainText("");
		arrayList = new ArrayList<>();
		syn = "null";
		ans = 0;
	}
	
	public void reboot() {
		syn = "null";
		setMainText("");
		arrayList.clear();
		ans = 0;
	}
	
	//��ʾ����
	boolean fullScreen() {
		if(mainText.length() > maxTextLength)return true;
		return false;
	}
	
	void clearScreen() {
		setMainText("");
	}
	
	boolean willFull(String text) {
		if(mainText.length() + text.length() > maxTextLength)return true;
		return false;
	}
	
	public void addText(String text) {
		if(willFull(text))return;
		mainText += text;
	}
	
	public void addDot() {
		if(!getMainText().contains("."))addText(".");
	}
	
	public void addZero() {
		if(getMainText().length()==0||!getMainText().substring(0,1).contains("0"))addText("0");
	}
	
	public void delText() {
		int length = mainText.length();
		if(length == 1) {
			setMainText("0");
		} else {
			setMainText(mainText.substring(0, length-1));
		}
	}
	
	public String getMainText() {
		return mainText;
	}

	public void setMainText(String mainText) {
		this.mainText = mainText;
	}
	
	//���㲿��
	public void equal() {
		arrayList.add(StringToNum(mainText));
		//ȷ���ǵ�Ԫ���㻹�Ƕ�Ԫ����
		int stringNum = arrayList.size();
		//number==0||1  ������һ����������=
		if(stringNum == 0 || stringNum == 1) {
			ans = StringToNum(mainText);
		} 
		//number==1  ��Ԫ����
		else if(stringNum == 2) {
			double num1 = arrayList.get(0);
			double num2 = arrayList.get(1);
			double tempAns;
			switch(syn) {
			case "+":
				tempAns = num1 + num2;
				if(isNOF(tempAns))NOF();
				else {
					ans = tempAns;
					setMainText(NumToString(tempAns));
				}
				break;
			case "-":
				tempAns = num1 - num2;
				if(isNOF(tempAns))NOF();
				else {
					ans = tempAns;
					setMainText(NumToString(tempAns));
				}
				break;	
			case "/":
				if(Math.abs(num2) < Math.pow(10, -28))DBZ();
				else {
					tempAns = num1 / num2;
					if(isNOF(tempAns))NOF();
					else {
						ans = tempAns;
						setMainText(NumToString(tempAns));
					}
				}
				break;
			case "X":
				tempAns = num1 * num2;
				if(isNOF(tempAns))NOF();
				else {
					ans = tempAns;
					setMainText(NumToString(tempAns));
				}
				break;
			default:
				NOF();
				break;
			}
		}
		syn = "null";
		arrayList.clear();
	}
	
	public void twoSyn(String twosyn) {
		if(syn != "null")
			return;
		syn = twosyn;
		arrayList.add(StringToNum(mainText));
		setMainText("");
	}
	
	public void oneSyn(String onesyn) {
		double num = StringToNum(mainText);
		double tempAns;
		switch(onesyn) {
		case "%":
			tempAns = num*100;
			if(isNOF(tempAns))NOF();
			else {
				setMainText(NumToString(tempAns));
			}
			break;
		case "��":
			tempAns = Math.pow(num, 0.5);
			if(isNOF(tempAns))NOF();
			else {
				setMainText(NumToString(tempAns));
			}
			break;
		case "x^2":
			tempAns = Math.pow(num, 2);
			if(isNOF(tempAns))NOF();
			else {
				setMainText(NumToString(tempAns));
			}
			break;
		case "1/x":
			if(Math.abs(num) < Math.pow(10, -28)) {
				DBZ();
				break;
			}
			tempAns = Math.pow(num, -1);
			if(isNOF(tempAns))NOF();
			else {
				setMainText(NumToString(tempAns));
			}
			break;
		default:
			IO();
			break;
		}
	}
	
	double StringToNum(String string) {
		if(string.contains("-")) {
			string = string.substring(1);
			return -Double.valueOf(string);
		}
		return Double.valueOf(string);
	}
	
	String NumToString(double num) {
		String temp = String.valueOf(num);
		if(temp.length() > maxTextLength-1)
			temp = temp.substring(0, maxTextLength-1);
		return temp;
	}
	
	//�쳣��������
	void NOF() {
		reboot();
		setMainText("Num Over Flow");
	}
	void DBZ() {
		reboot();
		setMainText("Division By Zero");
	}
	void IO() {
		reboot(); 
		setMainText("Illegal Operation");
	}
	
	boolean isNOF(double num) {
		if(num > Math.pow(10, maxTextLength))return true;
		return false;
	}

}
